// ABCLOUD Clientarea Auth Helper Functions
// Aligned with IDCsmart Finance 3.7.6 native authentication & Geetest compatibility

function encrypt(str) {
  // IDCsmart 3.7.6 native ViewClientsController checks cmf_password($_POST['password']) directly.
  // Preserving raw password avoids ciphertext mismatch and prevents DOM value jumping.
  return str;
}

function encryptPass(inputId, hiddenId) {
  return true;
}

function togglePwdVisibility(inputId, btn) {
  var input = document.getElementById(inputId);
  if (!input) return;
  var icon = btn.querySelector('i');
  if (input.type === 'password') {
    input.type = 'text';
    if (icon) {
      icon.classList.remove('bx-show');
      icon.classList.add('bx-hide');
    }
  } else {
    input.type = 'password';
    if (icon) {
      icon.classList.remove('bx-hide');
      icon.classList.add('bx-show');
    }
  }
}

function switchAuthTab(targetTabId, btn) {
  // Update buttons
  var parent = btn.closest('.abcloud-auth-tabs');
  if (parent) {
    var btns = parent.querySelectorAll('.abcloud-auth-tab-btn');
    btns.forEach(function (b) { b.classList.remove('active'); });
    btn.classList.add('active');
  }

  // Update panels
  var panels = document.querySelectorAll('.abcloud-tab-pane');
  panels.forEach(function (p) {
    p.classList.remove('active');
    p.style.display = 'none';
  });

  var target = document.getElementById(targetTabId);
  if (target) {
    target.classList.add('active');
    target.style.display = 'block';
  }
}

// Defensive deduplication of Geetest slots if multi-boot occurs
function deduplicateGeetestSlots() {
  var forms = document.querySelectorAll('form[action*="/login"], form[action*="/register"], form[action*="/pwreset"]');
  forms.forEach(function(form) {
    var slots = form.querySelectorAll('.geetest-captcha-slot');
    if (slots.length > 1) {
      for (var i = 1; i < slots.length; i++) {
        slots[i].remove();
      }
    }
  });
}

document.addEventListener("DOMContentLoaded", deduplicateGeetestSlots);

if (typeof MutationObserver !== 'undefined') {
  var geetestSlotObserver = new MutationObserver(function() {
    deduplicateGeetestSlots();
  });
  if (document.body) {
    geetestSlotObserver.observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener("DOMContentLoaded", function() {
      geetestSlotObserver.observe(document.body, { childList: true, subtree: true });
    });
  }
}
