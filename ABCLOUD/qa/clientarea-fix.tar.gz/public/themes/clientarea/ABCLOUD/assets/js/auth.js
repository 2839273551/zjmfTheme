// ABCLOUD Clientarea Auth Helper Functions
// Aligned with IDCsmart Finance native encryption & Geetest compatibility

function encrypt(str) {
  if (typeof CryptoJS === "undefined" || !CryptoJS.AES) {
    return str;
  }
  var key = CryptoJS.enc.Utf8.parse("idcsmart.finance");
  var iv = CryptoJS.enc.Utf8.parse("9311019310287172");
  return CryptoJS.AES.encrypt(str, key, {
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
    iv: iv
  }).toString();
}

/**
 * Encrypt password using shadow hidden input pattern.
 * Visible input is NEVER modified into ciphertext, preventing:
 * 1. Visual glitch (dots jumping to 24 chars).
 * 2. Double-encryption if submission is intercepted by Geetest or validation.
 * 3. Exposure of raw base64 string when user clicks eye toggle.
 */
function encryptPass(inputId, hiddenId) {
  var visibleInput = document.getElementById(inputId);
  if (!visibleInput) return true;
  var rawValue = visibleInput.value;
  if (!rawValue) return true;

  if (hiddenId) {
    var hiddenInput = document.getElementById(hiddenId);
    if (hiddenInput) {
      hiddenInput.value = encrypt(rawValue);
      return true;
    }
  }

  // Fallback for legacy calls without hidden input
  if (visibleInput.dataset.encrypted === "1") return true;
  visibleInput.value = encrypt(rawValue);
  visibleInput.dataset.encrypted = "1";
  return true;
}

// Reset legacy encryption flag if user types
document.addEventListener("input", function(e) {
  if (e.target && (e.target.type === "password" || (e.target.id && e.target.id.indexOf("Pwd") !== -1))) {
    delete e.target.dataset.encrypted;
  }
}, true);

function togglePwdVisibility(inputId, btn) {
  var input = document.getElementById(inputId);
  if (!input) return;
  var icon = btn.querySelector('i');
  if (input.type === 'password') {
    input.type = 'text';
    if (icon) {
      icon.classList.remove('bx-show');
      icon.classList.add('bx-hide');
    }
  } else {
    input.type = 'password';
    if (icon) {
      icon.classList.remove('bx-hide');
      icon.classList.add('bx-show');
    }
  }
}

function switchAuthTab(targetTabId, btn) {
  // Update buttons
  var parent = btn.closest('.abcloud-auth-tabs');
  if (parent) {
    var btns = parent.querySelectorAll('.abcloud-auth-tab-btn');
    btns.forEach(function (b) { b.classList.remove('active'); });
    btn.classList.add('active');
  }

  // Update panels
  var panels = document.querySelectorAll('.abcloud-tab-pane');
  panels.forEach(function (p) {
    p.classList.remove('active');
    p.style.display = 'none';
  });

  var target = document.getElementById(targetTabId);
  if (target) {
    target.classList.add('active');
    target.style.display = 'block';
  }
}

// Defensive deduplication of Geetest slots if multi-boot occurs
function deduplicateGeetestSlots() {
  var forms = document.querySelectorAll('form[action*="/login"], form[action*="/register"], form[action*="/pwreset"]');
  forms.forEach(function(form) {
    var slots = form.querySelectorAll('.geetest-captcha-slot');
    if (slots.length > 1) {
      for (var i = 1; i < slots.length; i++) {
        slots[i].remove();
      }
    }
  });
}

document.addEventListener("DOMContentLoaded", deduplicateGeetestSlots);

if (typeof MutationObserver !== 'undefined') {
  var geetestSlotObserver = new MutationObserver(function() {
    deduplicateGeetestSlots();
  });
  if (document.body) {
    geetestSlotObserver.observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener("DOMContentLoaded", function() {
      geetestSlotObserver.observe(document.body, { childList: true, subtree: true });
    });
  }
}
