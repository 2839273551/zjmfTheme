{if $TplName != 'login' && $TplName != 'register' && $TplName != 'pwreset' && $TplName != 'bind' && $TplName != 'loginaccesstoken'}
				</div>
			</div>
		</div>

		<footer class="footer">
			<div class="container-fluid">
				<div class="row align-items-center">
					<div class="col-sm-6">
						&copy; {$Setting.company_name} 版权所有.
					</div>
					<div class="col-sm-6 text-sm-right d-none d-sm-block">
						<span class="text-muted">高可用云计算与在线业务运营平台</span>
					</div>
				</div>
			</div>
		</footer>
{/if}

<script src="/themes/clientarea/default/assets/js/app.js?v={$Ver}"></script>
{php}
$hooks = hook('client_area_footer_output');
$outputted = '';
if (!empty($hooks)) {
    // 去重钩子输出，防止 ThinkCMF 模块级和系统级钩子双重注册导致脚本和插槽重复两份
    $uniqueHooks = array_unique((array)$hooks);
    foreach ($uniqueHooks as $item) {
        echo $item;
        $outputted .= (string)$item;
    }
}
if (in_array($TplName, ['login', 'register', 'pwreset']) && strpos($outputted, 'geetest-captcha.js') === false) {
    if (file_exists(CMF_ROOT . 'public/plugins/addons/geetest_captcha/assets/geetest-captcha.js')) {
        try {
            $gtPlugin = \think\Db::name('plugin')->where('name', 'GeetestCaptcha')->where('status', 1)->find();
            if ($gtPlugin && !empty($gtPlugin['config'])) {
                $gtConfig = json_decode($gtPlugin['config'], true);
                if (!empty($gtConfig['captcha_id']) && !empty($gtConfig['captcha_key'])) {
                    $pageMap = ['login' => 'login', 'register' => 'register', 'pwreset' => 'password_reset'];
                    $curPage = isset($pageMap[$TplName]) ? $pageMap[$TplName] : 'login';
                    $clientConfig = [
                        'page'        => $curPage,
                        'captchaId'   => trim((string)$gtConfig['captcha_id']),
                        'configured'  => true,
                        'product'     => isset($gtConfig['product']) ? $gtConfig['product'] : 'bind',
                        'riskType'    => (isset($gtConfig['risk_type']) && $gtConfig['risk_type'] !== 'auto') ? $gtConfig['risk_type'] : '',
                        'language'    => 'zho',
                        'timeout'     => 10000,
                    ];
                    $clientJson = json_encode($clientConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    echo '<script src="https://static.geetest.com/v4/gt4.js"></script>';
                    echo '<script src="/plugins/addons/geetest_captcha/assets/geetest-captcha.js?v=1.0.3"></script>';
                    echo '<script>if(window.GeetestCaptchaPlugin){window.GeetestCaptchaPlugin.boot(' . $clientJson . ');}</script>';
                }
            }
        } catch (\Throwable $e) {}
    }
}
{/php}
</body>

</html>
