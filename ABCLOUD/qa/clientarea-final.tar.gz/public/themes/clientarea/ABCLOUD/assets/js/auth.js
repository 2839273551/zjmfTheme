// ABCLOUD Clientarea Auth Helper Functions
function togglePwdVisibility(inputId, btn) {
  var input = document.getElementById(inputId);
  if (!input) return;
  var icon = btn.querySelector('i');
  if (input.type === 'password') {
    input.type = 'text';
    if (icon) {
      icon.classList.remove('bx-show');
      icon.classList.add('bx-hide');
    }
  } else {
    input.type = 'password';
    if (icon) {
      icon.classList.remove('bx-hide');
      icon.classList.add('bx-show');
    }
  }
}

function switchAuthTab(targetTabId, btn) {
  // Update buttons
  var parent = btn.closest('.abcloud-auth-tabs');
  if (parent) {
    var btns = parent.querySelectorAll('.abcloud-auth-tab-btn');
    btns.forEach(function (b) { b.classList.remove('active'); });
    btn.classList.add('active');
  }

  // Update panels
  var panels = document.querySelectorAll('.abcloud-tab-pane');
  panels.forEach(function (p) {
    p.classList.remove('active');
    p.style.display = 'none';
  });

  var target = document.getElementById(targetTabId);
  if (target) {
    target.classList.add('active');
    target.style.display = 'block';
  }
}
